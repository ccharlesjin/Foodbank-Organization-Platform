var express = require('express');
var router = express.Router();

// 处理局部内容加载的请求
router.get('/:section', function(req, res, next) {
    const section = req.params.section;
    switch (section) {
        case 'security':
            // 返回安全设置页面内容
            res.send('Email Verified: Yes <br> <button onclick="changePassword()">Change Password</button>');
            break;
        case 'activities':
            // 返回组织活动页面内容
            const activitiesHtml = `
                <div class="image-container">
                    <img src="/images/sydney.jpg" alt="Sydney Activities" class="activity-image">
                    <img src="/images/melbourne.jpg" alt="Melbourne Activities" class="activity-image">
                    <img src="/images/adelaide.jpg" alt="Adelaide Activities" class="activity-image">
                </div>
            `;
            res.send(activitiesHtml); // 确保发送 HTML 内容
            break;
        default:
            res.status(404).send('Section not found');
    }
});

module.exports = router;